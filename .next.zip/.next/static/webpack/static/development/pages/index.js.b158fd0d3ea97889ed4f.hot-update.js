webpackHotUpdate("static\\development\\pages\\index.js",{

/***/ "./pages/index.js":
/*!************************!*\
  !*** ./pages/index.js ***!
  \************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_toConsumableArray__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/toConsumableArray */ "./node_modules/@babel/runtime-corejs2/helpers/esm/toConsumableArray.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/classCallCheck */ "./node_modules/@babel/runtime-corejs2/helpers/esm/classCallCheck.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/createClass */ "./node_modules/@babel/runtime-corejs2/helpers/esm/createClass.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/possibleConstructorReturn */ "./node_modules/@babel/runtime-corejs2/helpers/esm/possibleConstructorReturn.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/getPrototypeOf */ "./node_modules/@babel/runtime-corejs2/helpers/esm/getPrototypeOf.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/inherits */ "./node_modules/@babel/runtime-corejs2/helpers/esm/inherits.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _components_AxieCard__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../components/AxieCard */ "./components/AxieCard.js");
/* harmony import */ var web3__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! web3 */ "./node_modules/web3/dist/web3.umd.js");
/* harmony import */ var web3__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(web3__WEBPACK_IMPORTED_MODULE_8__);






var _jsxFileName = "C:\\Users\\phill\\Documents\\dev\\web3testing\\pages\\index.js";




var AxieClockAuctionABI = __webpack_require__(/*! ../lib/AxieClockAuctionABI */ "./lib/AxieClockAuctionABI.json");

var AxieClockAuctionAddress = "0xF4985070Ce32b6B1994329DF787D1aCc9a2dd9e2";

var App =
/*#__PURE__*/
function (_Component) {
  Object(_babel_runtime_corejs2_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_5__["default"])(App, _Component);

  function App(props) {
    var _this;

    Object(_babel_runtime_corejs2_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_1__["default"])(this, App);

    _this = Object(_babel_runtime_corejs2_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_3__["default"])(this, Object(_babel_runtime_corejs2_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_4__["default"])(App).call(this, props));
    _this.state = {
      web3: new web3__WEBPACK_IMPORTED_MODULE_8___default.a(web3__WEBPACK_IMPORTED_MODULE_8___default.a.givenProvider, null, {}),
      axies: []
    };
    return _this;
  }

  Object(_babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_2__["default"])(App, [{
    key: "componentWillMount",
    value: function componentWillMount() {
      var _this2 = this;

      var contract = this.state.web3.eth.Contract(AxieClockAuctionABI, AxieClockAuctionAddress);
      this.state.web3.eth.getBlock('latest').then(function (r) {
        contract.getPastEvents('AuctionSuccessful', {
          fromBlock: r.number - 1000,
          toBlock: r.number
        }).then(function (responseArray) {
          console.log(responseArray);
          responseArray.forEach(function (response) {
            var _tokenId = response.returnValues[1],
                _totalPrice = response.returnValues[2];
            _totalPrice = _this2.state.web3.utils.fromWei(_totalPrice._hex, 'ether');
            _tokenId = _this2.state.web3.utils.hexToNumberString(_tokenId._hex);

            _this2.setState(function (prevState) {
              return {
                axies: [].concat(Object(_babel_runtime_corejs2_helpers_esm_toConsumableArray__WEBPACK_IMPORTED_MODULE_0__["default"])(prevState.axies), [{
                  _totalPrice: _totalPrice,
                  _tokenId: _tokenId
                }])
              };
            });
          });
        }).catch(function (e) {
          return console.error(e);
        });
      }).catch(function (e) {
        return console.error(e);
      });
    }
  }, {
    key: "render",
    value: function render() {
      var key = 1;
      return react__WEBPACK_IMPORTED_MODULE_6___default.a.createElement("div", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 53
        },
        __self: this
      }, this.state.axies.map(function (axie) {
        return react__WEBPACK_IMPORTED_MODULE_6___default.a.createElement(_components_AxieCard__WEBPACK_IMPORTED_MODULE_7__["default"], {
          key: key++,
          axieId: axie._tokenId,
          axiePrice: axie._totalPrice,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 55
          },
          __self: this
        });
      }));
    }
  }]);

  return App;
}(react__WEBPACK_IMPORTED_MODULE_6__["Component"]);

/* harmony default export */ __webpack_exports__["default"] = (App);

/***/ })

})
//# sourceMappingURL=index.js.b158fd0d3ea97889ed4f.hot-update.js.map